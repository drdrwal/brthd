gdjs.MainCode = {};
gdjs.MainCode.localVariables = [];
gdjs.MainCode.GDPlayerObjects1= [];
gdjs.MainCode.GDPlayerObjects2= [];
gdjs.MainCode.GDPlayerObjects3= [];
gdjs.MainCode.GDEnemy1Objects1= [];
gdjs.MainCode.GDEnemy1Objects2= [];
gdjs.MainCode.GDEnemy1Objects3= [];
gdjs.MainCode.GDGrassObjects1= [];
gdjs.MainCode.GDGrassObjects2= [];
gdjs.MainCode.GDGrassObjects3= [];
gdjs.MainCode.GDGroundObjects1= [];
gdjs.MainCode.GDGroundObjects2= [];
gdjs.MainCode.GDGroundObjects3= [];
gdjs.MainCode.GDCloudObjects1= [];
gdjs.MainCode.GDCloudObjects2= [];
gdjs.MainCode.GDCloudObjects3= [];
gdjs.MainCode.GDBearObjects1= [];
gdjs.MainCode.GDBearObjects2= [];
gdjs.MainCode.GDBearObjects3= [];
gdjs.MainCode.GDgrassGroundObjects1= [];
gdjs.MainCode.GDgrassGroundObjects2= [];
gdjs.MainCode.GDgrassGroundObjects3= [];
gdjs.MainCode.GDArrowObjects1= [];
gdjs.MainCode.GDArrowObjects2= [];
gdjs.MainCode.GDArrowObjects3= [];
gdjs.MainCode.GDHayObjects1= [];
gdjs.MainCode.GDHayObjects2= [];
gdjs.MainCode.GDHayObjects3= [];
gdjs.MainCode.GDNewTiledSpriteObjects1= [];
gdjs.MainCode.GDNewTiledSpriteObjects2= [];
gdjs.MainCode.GDNewTiledSpriteObjects3= [];
gdjs.MainCode.GDHay2Objects1= [];
gdjs.MainCode.GDHay2Objects2= [];
gdjs.MainCode.GDHay2Objects3= [];
gdjs.MainCode.GDcamzoomUpObjects1= [];
gdjs.MainCode.GDcamzoomUpObjects2= [];
gdjs.MainCode.GDcamzoomUpObjects3= [];
gdjs.MainCode.GDSkyObjects1= [];
gdjs.MainCode.GDSkyObjects2= [];
gdjs.MainCode.GDSkyObjects3= [];
gdjs.MainCode.GDbearJumpTrigObjects1= [];
gdjs.MainCode.GDbearJumpTrigObjects2= [];
gdjs.MainCode.GDbearJumpTrigObjects3= [];
gdjs.MainCode.GDmeadowObjects1= [];
gdjs.MainCode.GDmeadowObjects2= [];
gdjs.MainCode.GDmeadowObjects3= [];
gdjs.MainCode.GDStopPlayerObjects1= [];
gdjs.MainCode.GDStopPlayerObjects2= [];
gdjs.MainCode.GDStopPlayerObjects3= [];
gdjs.MainCode.GDCabinObjects1= [];
gdjs.MainCode.GDCabinObjects2= [];
gdjs.MainCode.GDCabinObjects3= [];
gdjs.MainCode.GDcamzoomUp2Objects1= [];
gdjs.MainCode.GDcamzoomUp2Objects2= [];
gdjs.MainCode.GDcamzoomUp2Objects3= [];
gdjs.MainCode.GDGrass3DObjects1= [];
gdjs.MainCode.GDGrass3DObjects2= [];
gdjs.MainCode.GDGrass3DObjects3= [];
gdjs.MainCode.GDCabin3DObjects1= [];
gdjs.MainCode.GDCabin3DObjects2= [];
gdjs.MainCode.GDCabin3DObjects3= [];
gdjs.MainCode.GDGroundGrass3DObjects1= [];
gdjs.MainCode.GDGroundGrass3DObjects2= [];
gdjs.MainCode.GDGroundGrass3DObjects3= [];
gdjs.MainCode.GDNewParticlesEmitterObjects1= [];
gdjs.MainCode.GDNewParticlesEmitterObjects2= [];
gdjs.MainCode.GDNewParticlesEmitterObjects3= [];
gdjs.MainCode.GDNewShapePainterObjects1= [];
gdjs.MainCode.GDNewShapePainterObjects2= [];
gdjs.MainCode.GDNewShapePainterObjects3= [];
gdjs.MainCode.GDBear1Objects1= [];
gdjs.MainCode.GDBear1Objects2= [];
gdjs.MainCode.GDBear1Objects3= [];
gdjs.MainCode.GDdoorObjects1= [];
gdjs.MainCode.GDdoorObjects2= [];
gdjs.MainCode.GDdoorObjects3= [];
gdjs.MainCode.GDhouseEntryTextObjects1= [];
gdjs.MainCode.GDhouseEntryTextObjects2= [];
gdjs.MainCode.GDhouseEntryTextObjects3= [];
gdjs.MainCode.GDControlsObjects1= [];
gdjs.MainCode.GDControlsObjects2= [];
gdjs.MainCode.GDControlsObjects3= [];
gdjs.MainCode.GDControls2Objects1= [];
gdjs.MainCode.GDControls2Objects2= [];
gdjs.MainCode.GDControls2Objects3= [];
gdjs.MainCode.GDControls3Objects1= [];
gdjs.MainCode.GDControls3Objects2= [];
gdjs.MainCode.GDControls3Objects3= [];
gdjs.MainCode.GDControls4Objects1= [];
gdjs.MainCode.GDControls4Objects2= [];
gdjs.MainCode.GDControls4Objects3= [];
gdjs.MainCode.GDhouseEnterControlObjects1= [];
gdjs.MainCode.GDhouseEnterControlObjects2= [];
gdjs.MainCode.GDhouseEnterControlObjects3= [];
gdjs.MainCode.GDmountain3DObjects1= [];
gdjs.MainCode.GDmountain3DObjects2= [];
gdjs.MainCode.GDmountain3DObjects3= [];
gdjs.MainCode.GDForest3DObjects1= [];
gdjs.MainCode.GDForest3DObjects2= [];
gdjs.MainCode.GDForest3DObjects3= [];
gdjs.MainCode.GDeastereggTextObjects1= [];
gdjs.MainCode.GDeastereggTextObjects2= [];
gdjs.MainCode.GDeastereggTextObjects3= [];
gdjs.MainCode.GDbearText2Objects1= [];
gdjs.MainCode.GDbearText2Objects2= [];
gdjs.MainCode.GDbearText2Objects3= [];
gdjs.MainCode.GDfadeScreenObjects1= [];
gdjs.MainCode.GDfadeScreenObjects2= [];
gdjs.MainCode.GDfadeScreenObjects3= [];
gdjs.MainCode.GDMenuObjects1= [];
gdjs.MainCode.GDMenuObjects2= [];
gdjs.MainCode.GDMenuObjects3= [];


gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects1});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDHay2Objects1Objects = Hashtable.newFrom({"Hay2": gdjs.MainCode.GDHay2Objects1});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDGroundObjects1Objects = Hashtable.newFrom({"Ground": gdjs.MainCode.GDGroundObjects1});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDHay2Objects1Objects = Hashtable.newFrom({"Hay2": gdjs.MainCode.GDHay2Objects1});
gdjs.MainCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects2});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDcamzoomUpObjects2Objects = Hashtable.newFrom({"camzoomUp": gdjs.MainCode.GDcamzoomUpObjects2});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects2});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDcamzoomUpObjects2Objects = Hashtable.newFrom({"camzoomUp": gdjs.MainCode.GDcamzoomUpObjects2});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects2});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDcamzoomUpObjects2Objects = Hashtable.newFrom({"camzoomUp": gdjs.MainCode.GDcamzoomUpObjects2});
gdjs.MainCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Controls"), gdjs.MainCode.GDControlsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Sky"), gdjs.MainCode.GDSkyObjects2);
gdjs.copyArray(runtimeScene.getObjects("camzoomUp"), gdjs.MainCode.GDcamzoomUpObjects2);
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), (( gdjs.MainCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDPlayerObjects2[0].getPointX("")), 0.1), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) - 20, (( gdjs.MainCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDPlayerObjects2[0].getPointY("")), 0.1), "", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraZoom(runtimeScene, "", 0), 1, 0.1), "", 0);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.MainCode.GDSkyObjects2.length !== 0 ? gdjs.MainCode.GDSkyObjects2[0] : null), true, "Background", 0);
}{for(var i = 0, len = gdjs.MainCode.GDcamzoomUpObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDcamzoomUpObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.MainCode.GDControlsObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDControlsObjects2[i].setAnimationFrame(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("camzoomUp"), gdjs.MainCode.GDcamzoomUpObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects2Objects, gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDcamzoomUpObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), false, false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Arrow"), gdjs.MainCode.GDArrowObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bear"), gdjs.MainCode.GDBearObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bear1"), gdjs.MainCode.GDBear1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Controls"), gdjs.MainCode.GDControlsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Controls2"), gdjs.MainCode.GDControls2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Controls3"), gdjs.MainCode.GDControls3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Controls4"), gdjs.MainCode.GDControls4Objects2);
{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), (( gdjs.MainCode.GDBearObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDBearObjects2[0].getPointY("")), 0.1), "", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), (( gdjs.MainCode.GDBearObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDBearObjects2[0].getPointX("")), 0.1), "", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraZoom(runtimeScene, "", 0), 0.4, 0.1), "", 0);
}{for(var i = 0, len = gdjs.MainCode.GDArrowObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDArrowObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.MainCode.GDControlsObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDControlsObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.MainCode.GDControls2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDControls2Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.MainCode.GDControls3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDControls3Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.MainCode.GDControls4Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDControls4Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.MainCode.GDBear1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDBear1Objects2[i].getBehavior("Opacity").setOpacity(gdjs.evtTools.common.lerp((gdjs.MainCode.GDBear1Objects2[i].getBehavior("Opacity").getOpacity()), 255, 0.1));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("camzoomUp"), gdjs.MainCode.GDcamzoomUpObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects2Objects, gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDcamzoomUpObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), true, false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Arrow"), gdjs.MainCode.GDArrowObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bear1"), gdjs.MainCode.GDBear1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Controls"), gdjs.MainCode.GDControlsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Controls2"), gdjs.MainCode.GDControls2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Controls3"), gdjs.MainCode.GDControls3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Controls4"), gdjs.MainCode.GDControls4Objects2);
{for(var i = 0, len = gdjs.MainCode.GDArrowObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDArrowObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.MainCode.GDControlsObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDControlsObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.MainCode.GDControls2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDControls2Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.MainCode.GDControls3Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDControls3Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.MainCode.GDControls4Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDControls4Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.MainCode.GDBear1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDBear1Objects2[i].getBehavior("Opacity").setOpacity(gdjs.evtTools.common.lerp((gdjs.MainCode.GDBear1Objects2[i].getBehavior("Opacity").getOpacity()), 255, 0.1));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("camzoomUp"), gdjs.MainCode.GDcamzoomUpObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects2Objects, gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDcamzoomUpObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bear1"), gdjs.MainCode.GDBear1Objects2);
{for(var i = 0, len = gdjs.MainCode.GDBear1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDBear1Objects2[i].getBehavior("Opacity").setOpacity(gdjs.evtTools.common.lerp((gdjs.MainCode.GDBear1Objects2[i].getBehavior("Opacity").getOpacity()), 0, 0.1));
}
}}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtsExt__CameraShake__StartShaking.func(runtimeScene, 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CameraShake__SetLayerShakingFrequency.func(runtimeScene, 0.3, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CameraShake__SetLayerRotationAmplitude.func(runtimeScene, 30, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CameraShake__SetDefaultTranslationAmplitude.func(runtimeScene, 0, 1000, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.MainCode.eventsList2 = function(runtimeScene) {

};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects1});
gdjs.MainCode.eventsList3 = function(runtimeScene) {

};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDHay2Objects1Objects = Hashtable.newFrom({"Hay2": gdjs.MainCode.GDHay2Objects1});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDbearJumpTrigObjects1Objects = Hashtable.newFrom({"bearJumpTrig": gdjs.MainCode.GDbearJumpTrigObjects1});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDBearObjects1Objects = Hashtable.newFrom({"Bear": gdjs.MainCode.GDBearObjects1});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDHay2Objects1Objects = Hashtable.newFrom({"Hay2": gdjs.MainCode.GDHay2Objects1});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects1});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDBearObjects1Objects = Hashtable.newFrom({"Bear": gdjs.MainCode.GDBearObjects1});
gdjs.MainCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.MainCode.GDPlayerObjects1, gdjs.MainCode.GDPlayerObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDPlayerObjects2[k] = gdjs.MainCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.MainCode.GDBearObjects1, gdjs.MainCode.GDBearObjects2);

{for(var i = 0, len = gdjs.MainCode.GDBearObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDBearObjects2[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

/* Reuse gdjs.MainCode.GDPlayerObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Right") ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDPlayerObjects1[k] = gdjs.MainCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDBearObjects1 */
{for(var i = 0, len = gdjs.MainCode.GDBearObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDBearObjects1[i].getBehavior("Flippable").flipX(false);
}
}}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects1});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDcamzoomUpObjects1Objects = Hashtable.newFrom({"camzoomUp": gdjs.MainCode.GDcamzoomUpObjects1});
gdjs.MainCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22272252);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.MainCode.GDbearText2Objects1, gdjs.MainCode.GDbearText2Objects2);

{for(var i = 0, len = gdjs.MainCode.GDbearText2Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDbearText2Objects2[i].setPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0),gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0));
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sounds\\heartspop.mp3", 2, false, 30, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("camzoomUp"), gdjs.MainCode.GDcamzoomUpObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects1Objects, gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDcamzoomUpObjects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDbearText2Objects1 */
{for(var i = 0, len = gdjs.MainCode.GDbearText2Objects1.length ;i < len;++i) {
    gdjs.MainCode.GDbearText2Objects1[i].getBehavior("Opacity").setOpacity(gdjs.evtTools.common.lerp((gdjs.MainCode.GDbearText2Objects1[i].getBehavior("Opacity").getOpacity()), 0, 0.1));
}
}}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects1});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDStopPlayerObjects1Objects = Hashtable.newFrom({"StopPlayer": gdjs.MainCode.GDStopPlayerObjects1});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEnemy1Objects1Objects = Hashtable.newFrom({"Enemy1": gdjs.MainCode.GDEnemy1Objects1});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects1});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEnemy1Objects1Objects = Hashtable.newFrom({"Enemy1": gdjs.MainCode.GDEnemy1Objects1});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects1});
gdjs.MainCode.asyncCallback22276180 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Enemy1"), gdjs.MainCode.GDEnemy1Objects2);

{for(var i = 0, len = gdjs.MainCode.GDEnemy1Objects2.length ;i < len;++i) {
    gdjs.MainCode.GDEnemy1Objects2[i].deleteFromScene(runtimeScene);
}
}gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDEnemy1Objects1) asyncObjectsList.addObject("Enemy1", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(4), (runtimeScene) => (gdjs.MainCode.asyncCallback22276180(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects1});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDcamzoomUp2Objects1Objects = Hashtable.newFrom({"camzoomUp2": gdjs.MainCode.GDcamzoomUp2Objects1});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects1});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEnemy1Objects1Objects = Hashtable.newFrom({"Enemy1": gdjs.MainCode.GDEnemy1Objects1});
gdjs.MainCode.asyncCallback22280548 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("NewParticlesEmitter"), gdjs.MainCode.GDNewParticlesEmitterObjects2);

{for(var i = 0, len = gdjs.MainCode.GDNewParticlesEmitterObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDNewParticlesEmitterObjects2[i].stopEmission();
}
}gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList7 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
for (const obj of gdjs.MainCode.GDNewParticlesEmitterObjects1) asyncObjectsList.addObject("NewParticlesEmitter", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(15), (runtimeScene) => (gdjs.MainCode.asyncCallback22280548(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects1});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDdoorObjects1Objects = Hashtable.newFrom({"door": gdjs.MainCode.GDdoorObjects1});
gdjs.MainCode.asyncCallback22283116 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.MainCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "House", false);
}gdjs.MainCode.localVariables.length = 0;
}
gdjs.MainCode.eventsList8 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.MainCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainCode.asyncCallback22283116(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(2).setBoolean(true);
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sounds\\doorOpen.mp3", 4, false, 25, 1);
}
{ //Subevents
gdjs.MainCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects1});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDdoorObjects1Objects = Hashtable.newFrom({"door": gdjs.MainCode.GDdoorObjects1});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects1});
gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDdoorObjects1Objects = Hashtable.newFrom({"door": gdjs.MainCode.GDdoorObjects1});
gdjs.MainCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Controls"), gdjs.MainCode.GDControlsObjects1);
gdjs.copyArray(runtimeScene.getObjects("fadeScreen"), gdjs.MainCode.GDfadeScreenObjects1);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SceneTime");
}{for(var i = 0, len = gdjs.MainCode.GDControlsObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDControlsObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.MainCode.GDfadeScreenObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDfadeScreenObjects1[i].setCenterPositionInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0),gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.MainCode.GDControlsObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDControlsObjects1[i].getBehavior("Animation").pauseAnimation();
}
}{gdjs.scene3d.camera.setCameraRotationX(runtimeScene, 30, "", 0);
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "sounds\\bearRoar.mp3");
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "sounds\\melody1.mp3", 1, false, 10, 1);
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "sounds\\windSound.mp3", 2, true, 10, 1);
}{gdjs.scene3d.camera.setFov(runtimeScene, 80, "", 0);
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(2).setBoolean(false);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Ground"), gdjs.MainCode.GDGroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Hay2"), gdjs.MainCode.GDHay2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("fadeScreen"), gdjs.MainCode.GDfadeScreenObjects1);
gdjs.copyArray(runtimeScene.getObjects("houseEnterControl"), gdjs.MainCode.GDhouseEnterControlObjects1);
{for(var i = 0, len = gdjs.MainCode.GDfadeScreenObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDfadeScreenObjects1[i].getBehavior("Opacity").setOpacity(gdjs.evtTools.common.lerp(((gdjs.MainCode.GDfadeScreenObjects1[i].getBehavior("Opacity").getOpacity())), 0, 0.01));
}
}{gdjs.evtsExt__PushableAndPullableBox__Pushing.func(runtimeScene, gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects1Objects, "PlatformerObject", gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDHay2Objects1Objects, "PlatformerObject", "Platform", 150, "Right", "Left", false, gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDGroundObjects1Objects, gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDHay2Objects1Objects, "PlatformerObject", "Platform", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.MainCode.GDhouseEnterControlObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDhouseEnterControlObjects1[i].hide();
}
}{gdjs.scene3d.camera.setCameraRotationX(runtimeScene, gdjs.evtTools.common.lerp(gdjs.scene3d.camera.getCameraRotationX(runtimeScene, "", 0), 0, 0.03), "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.MainCode.GDMenuObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDMenuObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDMenuObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDMenuObjects1[k] = gdjs.MainCode.GDMenuObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDMenuObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDPlayerObjects1[k] = gdjs.MainCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22244612);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sounds\\walking.mp3", 6, true, 40, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDPlayerObjects1[k] = gdjs.MainCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22245780);
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 6);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 6);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDPlayerObjects1[k] = gdjs.MainCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22247340);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sounds\\walking.mp3", 6, true, 40, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Right");
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 6);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDPlayerObjects1[k] = gdjs.MainCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22248884);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 6);
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sounds\\jump.mp3", 7, false, 50, 1);
}
{ //Subevents
gdjs.MainCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Jump") ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDPlayerObjects1[k] = gdjs.MainCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.MainCode.GDPlayerObjects1[i].getBehavior("Flippable").isFlippedX()) ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDPlayerObjects1[k] = gdjs.MainCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects1[i].setAngle(gdjs.evtTools.common.lerp((gdjs.MainCode.GDPlayerObjects1[i].getAngle()), -(20), 0.1));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Jump") ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDPlayerObjects1[k] = gdjs.MainCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects1[i].getBehavior("Flippable").isFlippedX() ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDPlayerObjects1[k] = gdjs.MainCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects1[i].setAngle(gdjs.evtTools.common.lerp((gdjs.MainCode.GDPlayerObjects1[i].getAngle()), 20, 0.1));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDPlayerObjects1[k] = gdjs.MainCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects1[i].setAngle(gdjs.evtTools.common.lerp((gdjs.MainCode.GDPlayerObjects1[i].getAngle()), 0, 0.05));
}
}}

}


{


gdjs.MainCode.eventsList1(runtimeScene);
}


{


gdjs.MainCode.eventsList2(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22261236);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cloud"), gdjs.MainCode.GDCloudObjects1);
{for(var i = 0, len = gdjs.MainCode.GDCloudObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDCloudObjects1[i].addForce(gdjs.randomInRange(1, 30), 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDPlayerObjects1[k] = gdjs.MainCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraZoom(runtimeScene, "", 0), (gdjs.evtTools.camera.getCameraZoom(runtimeScene, "", 0) - 0.2), 0.05), "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDPlayerObjects1[k] = gdjs.MainCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22263100);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects1[i].rotate(0, runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.MainCode.GDPlayerObjects1[k] = gdjs.MainCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects1[i].setAngle(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__PushableAndPullableBox__IsPushing.func(runtimeScene, gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
}

}


{


gdjs.MainCode.eventsList3(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Hay2"), gdjs.MainCode.GDHay2Objects1);
gdjs.copyArray(runtimeScene.getObjects("bearJumpTrig"), gdjs.MainCode.GDbearJumpTrigObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDHay2Objects1Objects, gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDbearJumpTrigObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22265068);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bear"), gdjs.MainCode.GDBearObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bear1"), gdjs.MainCode.GDBear1Objects1);
{for(var i = 0, len = gdjs.MainCode.GDBearObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDBearObjects1[i].getBehavior("Physics2").applyImpulse(1, 0.2, 0, 0);
}
}{for(var i = 0, len = gdjs.MainCode.GDBear1Objects1.length ;i < len;++i) {
    gdjs.MainCode.GDBear1Objects1[i].hide();
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sounds\\bearRoar.mp3", 1, false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bear"), gdjs.MainCode.GDBearObjects1);
gdjs.copyArray(runtimeScene.getObjects("Hay2"), gdjs.MainCode.GDHay2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDBearObjects1Objects, gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDHay2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22266812);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sounds\\hit.mp3", 3, false, 100, 1);
}{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bear"), gdjs.MainCode.GDBearObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects1Objects, gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDBearObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22267812);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDBearObjects1 */
{for(var i = 0, len = gdjs.MainCode.GDBearObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDBearObjects1[i].setAngle(0);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bear"), gdjs.MainCode.GDBearObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.MainCode.GDBearObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDBearObjects1[i].setX(gdjs.evtTools.common.lerp((gdjs.MainCode.GDBearObjects1[i].getPointX("")), (( gdjs.MainCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.MainCode.GDPlayerObjects1[0].getPointX("")), 0.02));
}
}
{ //Subevents
gdjs.MainCode.eventsList4(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), true, false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bear"), gdjs.MainCode.GDBearObjects1);
gdjs.copyArray(runtimeScene.getObjects("bearText2"), gdjs.MainCode.GDbearText2Objects1);
{for(var i = 0, len = gdjs.MainCode.GDbearText2Objects1.length ;i < len;++i) {
    gdjs.MainCode.GDbearText2Objects1[i].setPosition(gdjs.evtTools.common.lerp((gdjs.MainCode.GDbearText2Objects1[i].getX()), (( gdjs.MainCode.GDBearObjects1.length === 0 ) ? 0 :gdjs.MainCode.GDBearObjects1[0].getPointX("")) - 200, 0.1),gdjs.evtTools.common.lerp((gdjs.MainCode.GDbearText2Objects1[i].getY()), (( gdjs.MainCode.GDBearObjects1.length === 0 ) ? 0 :gdjs.MainCode.GDBearObjects1[0].getPointY("")) - 200, 0.1));
}
}
{ //Subevents
gdjs.MainCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("StopPlayer"), gdjs.MainCode.GDStopPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects1Objects, gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDStopPlayerObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects1[i].clearForces();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy1"), gdjs.MainCode.GDEnemy1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEnemy1Objects1Objects, gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects1Objects, 250, false);
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDEnemy1Objects1 */
/* Reuse gdjs.MainCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.MainCode.GDEnemy1Objects1.length ;i < len;++i) {
    gdjs.MainCode.GDEnemy1Objects1[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.MainCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.MainCode.GDPlayerObjects1[0].getPointX("")), (gdjs.MainCode.GDEnemy1Objects1[i].getPointY("")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy1"), gdjs.MainCode.GDEnemy1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEnemy1Objects1Objects, gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects1Objects, 250, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDEnemy1Objects1 */
gdjs.copyArray(runtimeScene.getObjects("StopPlayer"), gdjs.MainCode.GDStopPlayerObjects1);
{for(var i = 0, len = gdjs.MainCode.GDEnemy1Objects1.length ;i < len;++i) {
    gdjs.MainCode.GDEnemy1Objects1[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.MainCode.GDStopPlayerObjects1.length === 0 ) ? 0 :gdjs.MainCode.GDStopPlayerObjects1[0].getPointX("")), (gdjs.MainCode.GDEnemy1Objects1[i].getPointY("")));
}
}{for(var i = 0, len = gdjs.MainCode.GDEnemy1Objects1.length ;i < len;++i) {
    gdjs.MainCode.GDEnemy1Objects1[i].getBehavior("Pathfinding").setMaxSpeed(1200);
}
}
{ //Subevents
gdjs.MainCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("camzoomUp2"), gdjs.MainCode.GDcamzoomUp2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects1Objects, gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDcamzoomUp2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cabin3D"), gdjs.MainCode.GDCabin3DObjects1);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraZoom(runtimeScene, "", 0), 0.4, 0.1), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), (( gdjs.MainCode.GDCabin3DObjects1.length === 0 ) ? 0 :gdjs.MainCode.GDCabin3DObjects1[0].getY()), 0.1), "", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), (( gdjs.MainCode.GDCabin3DObjects1.length === 0 ) ? 0 :gdjs.MainCode.GDCabin3DObjects1[0].getX()), 0.1), "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy1"), gdjs.MainCode.GDEnemy1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects1Objects, gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDEnemy1Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Death", false);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bear"), gdjs.MainCode.GDBearObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter"), gdjs.MainCode.GDNewParticlesEmitterObjects1);
{for(var i = 0, len = gdjs.MainCode.GDNewParticlesEmitterObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDNewParticlesEmitterObjects1[i].setPosition((( gdjs.MainCode.GDBearObjects1.length === 0 ) ? 0 :gdjs.MainCode.GDBearObjects1[0].getPointX("")),(( gdjs.MainCode.GDBearObjects1.length === 0 ) ? 0 :gdjs.MainCode.GDBearObjects1[0].getPointY("")));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), false, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter"), gdjs.MainCode.GDNewParticlesEmitterObjects1);
{for(var i = 0, len = gdjs.MainCode.GDNewParticlesEmitterObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDNewParticlesEmitterObjects1[i].stopEmission();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter"), gdjs.MainCode.GDNewParticlesEmitterObjects1);
{for(var i = 0, len = gdjs.MainCode.GDNewParticlesEmitterObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDNewParticlesEmitterObjects1[i].startEmission();
}
}
{ //Subevents
gdjs.MainCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("door"), gdjs.MainCode.GDdoorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects1Objects, gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDdoorObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), true, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainCode.GDdoorObjects1 */
gdjs.copyArray(runtimeScene.getObjects("houseEnterControl"), gdjs.MainCode.GDhouseEnterControlObjects1);
gdjs.copyArray(runtimeScene.getObjects("houseEntryText"), gdjs.MainCode.GDhouseEntryTextObjects1);
{for(var i = 0, len = gdjs.MainCode.GDhouseEntryTextObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDhouseEntryTextObjects1[i].getBehavior("Text").setText("Wejdz");
}
}{for(var i = 0, len = gdjs.MainCode.GDhouseEntryTextObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDhouseEntryTextObjects1[i].setPosition((( gdjs.MainCode.GDdoorObjects1.length === 0 ) ? 0 :gdjs.MainCode.GDdoorObjects1[0].getPointX("")),(( gdjs.MainCode.GDdoorObjects1.length === 0 ) ? 0 :gdjs.MainCode.GDdoorObjects1[0].getPointY("")) - 50);
}
}{for(var i = 0, len = gdjs.MainCode.GDhouseEnterControlObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDhouseEnterControlObjects1[i].hide(false);
}
}
{ //Subevents
gdjs.MainCode.eventsList9(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("fadeScreen"), gdjs.MainCode.GDfadeScreenObjects1);
{for(var i = 0, len = gdjs.MainCode.GDfadeScreenObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDfadeScreenObjects1[i].getBehavior("Opacity").setOpacity(gdjs.evtTools.common.lerp(((gdjs.MainCode.GDfadeScreenObjects1[i].getBehavior("Opacity").getOpacity())), 256, 0.1));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("door"), gdjs.MainCode.GDdoorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects1Objects, gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDdoorObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22284860);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("houseEntryText"), gdjs.MainCode.GDhouseEntryTextObjects1);
{for(var i = 0, len = gdjs.MainCode.GDhouseEntryTextObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDhouseEntryTextObjects1[i].getBehavior("Text").setText("Nuh uh, to jest dom misia. \nSam nie wejdziesz");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("door"), gdjs.MainCode.GDdoorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDPlayerObjects1Objects, gdjs.MainCode.mapOfGDgdjs_9546MainCode_9546GDdoorObjects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22285652);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("houseEntryText"), gdjs.MainCode.GDhouseEntryTextObjects1);
{for(var i = 0, len = gdjs.MainCode.GDhouseEntryTextObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDhouseEntryTextObjects1[i].getBehavior("Text").setText("");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "SceneTime") >= 10;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Controls"), gdjs.MainCode.GDControlsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Controls2"), gdjs.MainCode.GDControls2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Controls3"), gdjs.MainCode.GDControls3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Controls4"), gdjs.MainCode.GDControls4Objects1);
{for(var i = 0, len = gdjs.MainCode.GDControlsObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDControlsObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.MainCode.GDControls3Objects1.length ;i < len;++i) {
    gdjs.MainCode.GDControls3Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.MainCode.GDControls4Objects1.length ;i < len;++i) {
    gdjs.MainCode.GDControls4Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.MainCode.GDControls2Objects1.length ;i < len;++i) {
    gdjs.MainCode.GDControls2Objects1[i].hide();
}
}}

}


};

gdjs.MainCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MainCode.GDPlayerObjects1.length = 0;
gdjs.MainCode.GDPlayerObjects2.length = 0;
gdjs.MainCode.GDPlayerObjects3.length = 0;
gdjs.MainCode.GDEnemy1Objects1.length = 0;
gdjs.MainCode.GDEnemy1Objects2.length = 0;
gdjs.MainCode.GDEnemy1Objects3.length = 0;
gdjs.MainCode.GDGrassObjects1.length = 0;
gdjs.MainCode.GDGrassObjects2.length = 0;
gdjs.MainCode.GDGrassObjects3.length = 0;
gdjs.MainCode.GDGroundObjects1.length = 0;
gdjs.MainCode.GDGroundObjects2.length = 0;
gdjs.MainCode.GDGroundObjects3.length = 0;
gdjs.MainCode.GDCloudObjects1.length = 0;
gdjs.MainCode.GDCloudObjects2.length = 0;
gdjs.MainCode.GDCloudObjects3.length = 0;
gdjs.MainCode.GDBearObjects1.length = 0;
gdjs.MainCode.GDBearObjects2.length = 0;
gdjs.MainCode.GDBearObjects3.length = 0;
gdjs.MainCode.GDgrassGroundObjects1.length = 0;
gdjs.MainCode.GDgrassGroundObjects2.length = 0;
gdjs.MainCode.GDgrassGroundObjects3.length = 0;
gdjs.MainCode.GDArrowObjects1.length = 0;
gdjs.MainCode.GDArrowObjects2.length = 0;
gdjs.MainCode.GDArrowObjects3.length = 0;
gdjs.MainCode.GDHayObjects1.length = 0;
gdjs.MainCode.GDHayObjects2.length = 0;
gdjs.MainCode.GDHayObjects3.length = 0;
gdjs.MainCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.MainCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.MainCode.GDNewTiledSpriteObjects3.length = 0;
gdjs.MainCode.GDHay2Objects1.length = 0;
gdjs.MainCode.GDHay2Objects2.length = 0;
gdjs.MainCode.GDHay2Objects3.length = 0;
gdjs.MainCode.GDcamzoomUpObjects1.length = 0;
gdjs.MainCode.GDcamzoomUpObjects2.length = 0;
gdjs.MainCode.GDcamzoomUpObjects3.length = 0;
gdjs.MainCode.GDSkyObjects1.length = 0;
gdjs.MainCode.GDSkyObjects2.length = 0;
gdjs.MainCode.GDSkyObjects3.length = 0;
gdjs.MainCode.GDbearJumpTrigObjects1.length = 0;
gdjs.MainCode.GDbearJumpTrigObjects2.length = 0;
gdjs.MainCode.GDbearJumpTrigObjects3.length = 0;
gdjs.MainCode.GDmeadowObjects1.length = 0;
gdjs.MainCode.GDmeadowObjects2.length = 0;
gdjs.MainCode.GDmeadowObjects3.length = 0;
gdjs.MainCode.GDStopPlayerObjects1.length = 0;
gdjs.MainCode.GDStopPlayerObjects2.length = 0;
gdjs.MainCode.GDStopPlayerObjects3.length = 0;
gdjs.MainCode.GDCabinObjects1.length = 0;
gdjs.MainCode.GDCabinObjects2.length = 0;
gdjs.MainCode.GDCabinObjects3.length = 0;
gdjs.MainCode.GDcamzoomUp2Objects1.length = 0;
gdjs.MainCode.GDcamzoomUp2Objects2.length = 0;
gdjs.MainCode.GDcamzoomUp2Objects3.length = 0;
gdjs.MainCode.GDGrass3DObjects1.length = 0;
gdjs.MainCode.GDGrass3DObjects2.length = 0;
gdjs.MainCode.GDGrass3DObjects3.length = 0;
gdjs.MainCode.GDCabin3DObjects1.length = 0;
gdjs.MainCode.GDCabin3DObjects2.length = 0;
gdjs.MainCode.GDCabin3DObjects3.length = 0;
gdjs.MainCode.GDGroundGrass3DObjects1.length = 0;
gdjs.MainCode.GDGroundGrass3DObjects2.length = 0;
gdjs.MainCode.GDGroundGrass3DObjects3.length = 0;
gdjs.MainCode.GDNewParticlesEmitterObjects1.length = 0;
gdjs.MainCode.GDNewParticlesEmitterObjects2.length = 0;
gdjs.MainCode.GDNewParticlesEmitterObjects3.length = 0;
gdjs.MainCode.GDNewShapePainterObjects1.length = 0;
gdjs.MainCode.GDNewShapePainterObjects2.length = 0;
gdjs.MainCode.GDNewShapePainterObjects3.length = 0;
gdjs.MainCode.GDBear1Objects1.length = 0;
gdjs.MainCode.GDBear1Objects2.length = 0;
gdjs.MainCode.GDBear1Objects3.length = 0;
gdjs.MainCode.GDdoorObjects1.length = 0;
gdjs.MainCode.GDdoorObjects2.length = 0;
gdjs.MainCode.GDdoorObjects3.length = 0;
gdjs.MainCode.GDhouseEntryTextObjects1.length = 0;
gdjs.MainCode.GDhouseEntryTextObjects2.length = 0;
gdjs.MainCode.GDhouseEntryTextObjects3.length = 0;
gdjs.MainCode.GDControlsObjects1.length = 0;
gdjs.MainCode.GDControlsObjects2.length = 0;
gdjs.MainCode.GDControlsObjects3.length = 0;
gdjs.MainCode.GDControls2Objects1.length = 0;
gdjs.MainCode.GDControls2Objects2.length = 0;
gdjs.MainCode.GDControls2Objects3.length = 0;
gdjs.MainCode.GDControls3Objects1.length = 0;
gdjs.MainCode.GDControls3Objects2.length = 0;
gdjs.MainCode.GDControls3Objects3.length = 0;
gdjs.MainCode.GDControls4Objects1.length = 0;
gdjs.MainCode.GDControls4Objects2.length = 0;
gdjs.MainCode.GDControls4Objects3.length = 0;
gdjs.MainCode.GDhouseEnterControlObjects1.length = 0;
gdjs.MainCode.GDhouseEnterControlObjects2.length = 0;
gdjs.MainCode.GDhouseEnterControlObjects3.length = 0;
gdjs.MainCode.GDmountain3DObjects1.length = 0;
gdjs.MainCode.GDmountain3DObjects2.length = 0;
gdjs.MainCode.GDmountain3DObjects3.length = 0;
gdjs.MainCode.GDForest3DObjects1.length = 0;
gdjs.MainCode.GDForest3DObjects2.length = 0;
gdjs.MainCode.GDForest3DObjects3.length = 0;
gdjs.MainCode.GDeastereggTextObjects1.length = 0;
gdjs.MainCode.GDeastereggTextObjects2.length = 0;
gdjs.MainCode.GDeastereggTextObjects3.length = 0;
gdjs.MainCode.GDbearText2Objects1.length = 0;
gdjs.MainCode.GDbearText2Objects2.length = 0;
gdjs.MainCode.GDbearText2Objects3.length = 0;
gdjs.MainCode.GDfadeScreenObjects1.length = 0;
gdjs.MainCode.GDfadeScreenObjects2.length = 0;
gdjs.MainCode.GDfadeScreenObjects3.length = 0;
gdjs.MainCode.GDMenuObjects1.length = 0;
gdjs.MainCode.GDMenuObjects2.length = 0;
gdjs.MainCode.GDMenuObjects3.length = 0;

gdjs.MainCode.eventsList10(runtimeScene);
gdjs.MainCode.GDPlayerObjects1.length = 0;
gdjs.MainCode.GDPlayerObjects2.length = 0;
gdjs.MainCode.GDPlayerObjects3.length = 0;
gdjs.MainCode.GDEnemy1Objects1.length = 0;
gdjs.MainCode.GDEnemy1Objects2.length = 0;
gdjs.MainCode.GDEnemy1Objects3.length = 0;
gdjs.MainCode.GDGrassObjects1.length = 0;
gdjs.MainCode.GDGrassObjects2.length = 0;
gdjs.MainCode.GDGrassObjects3.length = 0;
gdjs.MainCode.GDGroundObjects1.length = 0;
gdjs.MainCode.GDGroundObjects2.length = 0;
gdjs.MainCode.GDGroundObjects3.length = 0;
gdjs.MainCode.GDCloudObjects1.length = 0;
gdjs.MainCode.GDCloudObjects2.length = 0;
gdjs.MainCode.GDCloudObjects3.length = 0;
gdjs.MainCode.GDBearObjects1.length = 0;
gdjs.MainCode.GDBearObjects2.length = 0;
gdjs.MainCode.GDBearObjects3.length = 0;
gdjs.MainCode.GDgrassGroundObjects1.length = 0;
gdjs.MainCode.GDgrassGroundObjects2.length = 0;
gdjs.MainCode.GDgrassGroundObjects3.length = 0;
gdjs.MainCode.GDArrowObjects1.length = 0;
gdjs.MainCode.GDArrowObjects2.length = 0;
gdjs.MainCode.GDArrowObjects3.length = 0;
gdjs.MainCode.GDHayObjects1.length = 0;
gdjs.MainCode.GDHayObjects2.length = 0;
gdjs.MainCode.GDHayObjects3.length = 0;
gdjs.MainCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.MainCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.MainCode.GDNewTiledSpriteObjects3.length = 0;
gdjs.MainCode.GDHay2Objects1.length = 0;
gdjs.MainCode.GDHay2Objects2.length = 0;
gdjs.MainCode.GDHay2Objects3.length = 0;
gdjs.MainCode.GDcamzoomUpObjects1.length = 0;
gdjs.MainCode.GDcamzoomUpObjects2.length = 0;
gdjs.MainCode.GDcamzoomUpObjects3.length = 0;
gdjs.MainCode.GDSkyObjects1.length = 0;
gdjs.MainCode.GDSkyObjects2.length = 0;
gdjs.MainCode.GDSkyObjects3.length = 0;
gdjs.MainCode.GDbearJumpTrigObjects1.length = 0;
gdjs.MainCode.GDbearJumpTrigObjects2.length = 0;
gdjs.MainCode.GDbearJumpTrigObjects3.length = 0;
gdjs.MainCode.GDmeadowObjects1.length = 0;
gdjs.MainCode.GDmeadowObjects2.length = 0;
gdjs.MainCode.GDmeadowObjects3.length = 0;
gdjs.MainCode.GDStopPlayerObjects1.length = 0;
gdjs.MainCode.GDStopPlayerObjects2.length = 0;
gdjs.MainCode.GDStopPlayerObjects3.length = 0;
gdjs.MainCode.GDCabinObjects1.length = 0;
gdjs.MainCode.GDCabinObjects2.length = 0;
gdjs.MainCode.GDCabinObjects3.length = 0;
gdjs.MainCode.GDcamzoomUp2Objects1.length = 0;
gdjs.MainCode.GDcamzoomUp2Objects2.length = 0;
gdjs.MainCode.GDcamzoomUp2Objects3.length = 0;
gdjs.MainCode.GDGrass3DObjects1.length = 0;
gdjs.MainCode.GDGrass3DObjects2.length = 0;
gdjs.MainCode.GDGrass3DObjects3.length = 0;
gdjs.MainCode.GDCabin3DObjects1.length = 0;
gdjs.MainCode.GDCabin3DObjects2.length = 0;
gdjs.MainCode.GDCabin3DObjects3.length = 0;
gdjs.MainCode.GDGroundGrass3DObjects1.length = 0;
gdjs.MainCode.GDGroundGrass3DObjects2.length = 0;
gdjs.MainCode.GDGroundGrass3DObjects3.length = 0;
gdjs.MainCode.GDNewParticlesEmitterObjects1.length = 0;
gdjs.MainCode.GDNewParticlesEmitterObjects2.length = 0;
gdjs.MainCode.GDNewParticlesEmitterObjects3.length = 0;
gdjs.MainCode.GDNewShapePainterObjects1.length = 0;
gdjs.MainCode.GDNewShapePainterObjects2.length = 0;
gdjs.MainCode.GDNewShapePainterObjects3.length = 0;
gdjs.MainCode.GDBear1Objects1.length = 0;
gdjs.MainCode.GDBear1Objects2.length = 0;
gdjs.MainCode.GDBear1Objects3.length = 0;
gdjs.MainCode.GDdoorObjects1.length = 0;
gdjs.MainCode.GDdoorObjects2.length = 0;
gdjs.MainCode.GDdoorObjects3.length = 0;
gdjs.MainCode.GDhouseEntryTextObjects1.length = 0;
gdjs.MainCode.GDhouseEntryTextObjects2.length = 0;
gdjs.MainCode.GDhouseEntryTextObjects3.length = 0;
gdjs.MainCode.GDControlsObjects1.length = 0;
gdjs.MainCode.GDControlsObjects2.length = 0;
gdjs.MainCode.GDControlsObjects3.length = 0;
gdjs.MainCode.GDControls2Objects1.length = 0;
gdjs.MainCode.GDControls2Objects2.length = 0;
gdjs.MainCode.GDControls2Objects3.length = 0;
gdjs.MainCode.GDControls3Objects1.length = 0;
gdjs.MainCode.GDControls3Objects2.length = 0;
gdjs.MainCode.GDControls3Objects3.length = 0;
gdjs.MainCode.GDControls4Objects1.length = 0;
gdjs.MainCode.GDControls4Objects2.length = 0;
gdjs.MainCode.GDControls4Objects3.length = 0;
gdjs.MainCode.GDhouseEnterControlObjects1.length = 0;
gdjs.MainCode.GDhouseEnterControlObjects2.length = 0;
gdjs.MainCode.GDhouseEnterControlObjects3.length = 0;
gdjs.MainCode.GDmountain3DObjects1.length = 0;
gdjs.MainCode.GDmountain3DObjects2.length = 0;
gdjs.MainCode.GDmountain3DObjects3.length = 0;
gdjs.MainCode.GDForest3DObjects1.length = 0;
gdjs.MainCode.GDForest3DObjects2.length = 0;
gdjs.MainCode.GDForest3DObjects3.length = 0;
gdjs.MainCode.GDeastereggTextObjects1.length = 0;
gdjs.MainCode.GDeastereggTextObjects2.length = 0;
gdjs.MainCode.GDeastereggTextObjects3.length = 0;
gdjs.MainCode.GDbearText2Objects1.length = 0;
gdjs.MainCode.GDbearText2Objects2.length = 0;
gdjs.MainCode.GDbearText2Objects3.length = 0;
gdjs.MainCode.GDfadeScreenObjects1.length = 0;
gdjs.MainCode.GDfadeScreenObjects2.length = 0;
gdjs.MainCode.GDfadeScreenObjects3.length = 0;
gdjs.MainCode.GDMenuObjects1.length = 0;
gdjs.MainCode.GDMenuObjects2.length = 0;
gdjs.MainCode.GDMenuObjects3.length = 0;


return;

}

gdjs['MainCode'] = gdjs.MainCode;
